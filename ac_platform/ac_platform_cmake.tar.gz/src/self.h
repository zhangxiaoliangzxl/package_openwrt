#ifndef __SELF_H__
#define __SELF_H__

extern int mychmod(char *field, int mode);

#endif
